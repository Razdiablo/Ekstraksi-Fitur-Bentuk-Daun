import streamlit as st
import numpy as np
import cv2
from PIL import Image
from src.load_data import load_images_and_labels
from src.features import extract_color_features, extract_texture_features
from src.features import extract_features, visualize_glcm, augment_image
from src.model import train_and_evaluate_model, train_model_only
import matplotlib.pyplot as plt
from streamlit_lottie import st_lottie
import json
import time
import requests

# Konfigurasi halaman
st.set_page_config(
    page_title="Klasifikasi Daun Tanaman Obat",
    page_icon="🌿",
    layout="centered",
    initial_sidebar_state="expanded"
)

# Fungsi untuk memuat animasi Lottie
def load_lottieurl(url: str):
    r = requests.get(url)
    if r.status_code != 200:
        return None
    return r.json()

# Animasi Lottie
lottie_plant = load_lottieurl("https://assets1.lottiefiles.com/packages/lf20_vybwn7df.json")
lottie_upload = load_lottieurl("https://assets1.lottiefiles.com/packages/lf20_kvw0tnwb.json")
lottie_ai = load_lottieurl("https://assets1.lottiefiles.com/packages/lf20_6wutsrox.json")

# CSS Kustom
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Poppins', sans-serif;
    }
    
    .main {
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }
    
    .stButton>button {
        background: linear-gradient(135deg, #6B73FF 0%, #000DFF 100%);
        color: white;
        border: none;
        padding: 0.5rem 1rem;
        border-radius: 10px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }
    
    .stTextInput>div>div>input {
        border-radius: 10px;
        padding: 0.5rem;
    }
    
    .stFileUploader>div>div>button {
        border-radius: 10px;
    }
    
    .success-box {
        background: linear-gradient(135deg, #d4fc79 0%, #96e6a1 100%);
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .warning-box {
        background: linear-gradient(135deg, #f6d365 0%, #fda085 100%);
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .error-box {
        background: linear-gradient(135deg, #ff758c 0%, #ff7eb3 100%);
        padding: 1rem;
        border-radius: 10px;
        margin: 1rem 0;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .header-animation {
        animation: fadeIn 1.5s ease-in-out;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .card {
        background: white;
        border-radius: 15px;
        padding: 1.5rem;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
        margin-bottom: 1.5rem;
        transition: all 0.3s ease;
    }
    
    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
    }
</style>
""", unsafe_allow_html=True)

# Header dengan animasi
col1, col2 = st.columns([3, 1])
with col1:
    st.markdown("<h1 class='header-animation'>🌿 Klasifikasi Daun Tanaman Obat</h1>", unsafe_allow_html=True)
    st.markdown("""
    <p style='font-size: 1.1rem;'>
    Aplikasi ini menggunakan teknik <i>computer vision</i> dan machine learning untuk mengklasifikasikan 
    jenis tanaman obat berdasarkan gambar daunnya.
    </p>
    """, unsafe_allow_html=True)
with col2:
    if lottie_plant:
        st_lottie(lottie_plant, height=150, key="plant")

# Mode 1: Klasifikasi dari Dataset
with st.container():
    st.markdown("""<div class='card'>
    <h2>🔍 Mode 1: Klasifikasi dari Dataset</h2>
    <p>Latih model menggunakan dataset gambar daun yang telah disiapkan.</p>
    </div>""", unsafe_allow_html=True)
    
    dataset_path = st.text_input("📁 Path ke folder dataset:", "Dataset/", key="dataset_path")

    if st.button("🚀 Mulai Klasifikasi Dataset", key="train_button"):
        with st.spinner("🔄 Memuat data dan melatih model..."):
            progress_bar = st.progress(0)
            
            # Animasi loading
            with st.empty():
                if lottie_ai:
                    st_lottie(lottie_ai, height=100, key="loading_ai")
            
            for percent_complete in range(100):
                time.sleep(0.02)
                progress_bar.progress(percent_complete + 1)
            
            images, labels = load_images_and_labels(dataset_path)
            if not images:
                st.markdown("""<div class='error-box'>
                ❌ Tidak ditemukan gambar dalam folder yang diberikan.
                </div>""", unsafe_allow_html=True)
            else:
                X, y = extract_features(images, labels)
                st.markdown(f"""<div class='success-box'>
                ✅ Berhasil memuat {len(images)} gambar dengan {len(set(labels))} kelas.
                </div>""", unsafe_allow_html=True)
                
                # Visualisasi proses training
                with st.expander("📊 Proses Pelatihan Model"):
                    fig = train_and_evaluate_model(X, y)
                    if fig:
                        st.pyplot(fig)
                
# Pembatas dengan animasi
st.markdown("---")
with st.container():
    cols = st.columns(5)
    for i, col in enumerate(cols):
        with col:
            st.markdown(f"<div style='text-align: center;'>✨</div>", unsafe_allow_html=True)
            time.sleep(0.1)

# Mode 2: Prediksi Gambar Daun
with st.container():
    st.markdown("""<div class='card'>
    <h2>📸 Mode 2: Prediksi Gambar Daun</h2>
    <p>Unggah gambar daun untuk diprediksi jenis tanaman obatnya.</p>
    </div>""", unsafe_allow_html=True)
    
    uploaded_file = st.file_uploader("Pilih gambar daun (JPG, JPEG, PNG)", type=["jpg", "jpeg", "png"], key="file_uploader")
    
    if uploaded_file is not None:
        # Animasi upload
        with st.empty():
            if lottie_upload:
                st_lottie(lottie_upload, height=150, key="upload_anim")
            time.sleep(2)
        
        # Proses gambar
        image = Image.open(uploaded_file).convert("RGB")
        img_array = np.array(image)
        
        # Tampilkan gambar dengan efek
        st.markdown("### 🌿 Gambar yang Diunggah")
        st.image(img_array, caption="Gambar Daun", use_column_width=True)
        
        # Visualisasi GLCM
        with st.spinner("🔍 Menganalisis tekstur daun..."):
            time.sleep(1)
            fig_glcm = visualize_glcm(img_array)
            st.markdown("### 🧩 Visualisasi GLCM")
            st.pyplot(fig_glcm)
        
        # Prediksi
        with st.spinner("🧠 Memprediksi jenis tanaman..."):
            images, labels = load_images_and_labels(dataset_path)
            if images:
                X, y = extract_features(images, labels)
                model, classes = train_model_only(X, y)
                color_feat = extract_color_features(img_array)
                texture_feat = extract_texture_features(img_array)
                combined_feat = np.array(color_feat + texture_feat).reshape(1, -1)
                prediction = model.predict(combined_feat)[0]
                
                # Animasi hasil
                st.markdown(f"""<div class='success-box' style='animation: pulse 2s infinite;'>
                <h3 style='color: #2e7d32;'>🌱 Hasil Prediksi: <strong>{prediction}</strong></h3>
                </div>""", unsafe_allow_html=True)
            else:
                st.markdown("""<div class='warning-box'>
                ⚠️ Mohon jalankan pelatihan model dari dataset terlebih dahulu.
                </div>""", unsafe_allow_html=True)
