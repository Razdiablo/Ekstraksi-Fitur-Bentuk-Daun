import cv2
import numpy as np
import pandas as pd
from skimage.color import rgb2gray
from skimage.feature import graycomatrix, graycoprops

def extract_color_features(image):
    hsv = cv2.cvtColor(image, cv2.COLOR_RGB2HSV)
    H, S, V = cv2.split(hsv)
    return [np.mean(H), np.std(H), np.mean(S), np.std(S), np.mean(V), np.std(V)]

def extract_texture_features(image):
    gray = rgb2gray(image)
    gray = (gray * 255).astype(np.uint8)
    glcm = graycomatrix(gray, distances=[1], angles=[0], levels=256, symmetric=True, normed=True)
    return [
        graycoprops(glcm, 'contrast')[0, 0],
        graycoprops(glcm, 'dissimilarity')[0, 0],
        graycoprops(glcm, 'homogeneity')[0, 0],
        graycoprops(glcm, 'energy')[0, 0],
        graycoprops(glcm, 'correlation')[0, 0]
    ]

def extract_features(images, labels):
    features = []
    for img in images:
        color_feat = extract_color_features(img)
        texture_feat = extract_texture_features(img)
        combined = color_feat + texture_feat
        features.append(combined)
    df = pd.DataFrame(features)
    df['label'] = labels
    X = df.drop('label', axis=1)
    y = df['label']
    return X, y

import cv2

def augment_image(img):
    flipped = cv2.flip(img, 1)
    rotated = cv2.rotate(img, cv2.ROTATE_90_CLOCKWISE)
    rotated = cv2.resize(rotated, (224, 224))  # jaga shape konsisten
    return [img, flipped, rotated]


def visualize_glcm(image):
    import matplotlib.pyplot as plt
    from skimage.color import rgb2gray
    from skimage.feature import graycomatrix

    gray = rgb2gray(image)
    gray = (gray * 255).astype(np.uint8)
    glcm = graycomatrix(gray, distances=[1], angles=[0], levels=256, symmetric=True, normed=True)

    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].imshow(gray, cmap='gray')
    ax[0].set_title('Citra Grayscale')
    ax[0].axis('off')

    ax[1].imshow(glcm[:, :, 0, 0], cmap='viridis')
    ax[1].set_title('GLCM Matrix (d=1, angle=0)')
    ax[1].axis('off')

    plt.tight_layout()
    return fig
