import os
import cv2
from .features import augment_image

def load_images_and_labels(dataset_folder, augment=False, target_size=(224, 224)):
    images = []
    labels = []
    for root, dirs, files in os.walk(dataset_folder):
        for f in files:
            if f.lower().endswith(('.jpg', '.jpeg', '.png')):
                path = os.path.join(root, f)
                img = cv2.imread(path)
                if img is not None:
                    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                    img = cv2.resize(img, target_size)
                    if augment:
                        augmented_imgs = augment_image(img)
                        images.extend(augmented_imgs)
                        labels.extend([os.path.basename(root)] * len(augmented_imgs))
                    else:
                        images.append(img)
                        labels.append(os.path.basename(root))
    return images, labels
