import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model as keras_load_model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import pickle


MODEL_PATH = "saved_model/cnn_model.h5"
LABEL_ENCODER_PATH = "saved_model/label_encoder.pkl"


def preprocess_data(images, labels, img_size=(224, 224)):
    expected_shape = (img_size[0], img_size[1], 3)
    filtered_images = []
    filtered_labels = []

    for img, label in zip(images, labels):
        if isinstance(img, np.ndarray) and img.shape == expected_shape:
            filtered_images.append(img.astype(np.float32) / 255.0)
            filtered_labels.append(label)
        else:
            print(f"[WARNING] Gambar di-skip. Shape: {getattr(img, 'shape', 'invalid')}")

    if len(filtered_images) == 0:
        raise ValueError("❌ Tidak ada gambar dengan shape (224, 224, 3). Pastikan resize di-load_images_and_labels().")

    X = np.stack(filtered_images)
    le = LabelEncoder()
    y = le.fit_transform(filtered_labels)
    y_cat = to_categorical(y)

    return X, y_cat, le


def build_cnn_model(input_shape, num_classes):
    model = Sequential()
    model.add(Conv2D(32, (3, 3), activation='relu', input_shape=input_shape))
    model.add(MaxPooling2D(2, 2))
    model.add(Conv2D(64, (3, 3), activation='relu'))
    model.add(MaxPooling2D(2, 2))
    model.add(Flatten())
    model.add(Dense(128, activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(num_classes, activation='softmax'))

    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return model


def save_model(model, label_encoder):
    os.makedirs("saved_model", exist_ok=True)
    model.save(MODEL_PATH)
    with open(LABEL_ENCODER_PATH, 'wb') as f:
        pickle.dump(label_encoder, f)
    print("✅ Model dan LabelEncoder disimpan.")


def load_saved_model():
    if not os.path.exists(MODEL_PATH) or not os.path.exists(LABEL_ENCODER_PATH):
        raise FileNotFoundError("Model atau LabelEncoder tidak ditemukan.")
    model = keras_load_model(MODEL_PATH)
    with open(LABEL_ENCODER_PATH, 'rb') as f:
        label_encoder = pickle.load(f)
    print("✅ Model dan LabelEncoder berhasil dimuat.")
    return model, label_encoder


def train_cnn(images, labels, epochs=15):
    X, y, label_encoder = preprocess_data(images, labels)

    print("✅ X shape:", X.shape, "dtype:", X.dtype)
    print("✅ y shape:", y.shape, "dtype:", y.dtype)

    if not isinstance(X, np.ndarray) or not isinstance(y, np.ndarray):
        raise ValueError("X dan y harus berupa numpy array.")

    if np.any(np.isnan(X)) or np.any(np.isnan(y)):
        raise ValueError("Data X atau y mengandung NaN.")

    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )

    model = build_cnn_model(X.shape[1:], num_classes=y.shape[1])

    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=32,
        verbose=1
    )

    save_model(model, label_encoder)

    return model, history, label_encoder