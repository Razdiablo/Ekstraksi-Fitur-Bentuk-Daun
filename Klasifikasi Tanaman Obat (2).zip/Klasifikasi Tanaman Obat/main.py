from src.load_data import load_images_and_labels
from src.features import extract_features
from src.model import train_and_evaluate_model
from src.load_data import load_images_and_labels
from cnn_model import train_cnn

# Load dan augmentasi dataset
images, labels = load_images_and_labels("Dataset/", augment=True)

# Train CNN model
model, history, label_encoder = train_cnn(images, labels, epochs=20)


# Ekstraksi fitur
X, y = extract_features(images, labels)

# Training dan evaluasi model
train_and_evaluate_model(X, y)
